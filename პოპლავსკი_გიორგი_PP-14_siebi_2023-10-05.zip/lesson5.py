

#  1          3 momxmareblis info
# Costumer_info = []
# cost1= []
# cost2= []
# cost3= []
# while len(cost1)<3:    
#     a = (input("Type fist user Name/Surname/age"))
#     cost1.append(a)
# while len(cost2)<3:    
#     a = (input("Type second Name/Surname/age"))
#     cost2.append(a)
# while len(cost3)<3:    
#     a = (input("Type third Name/Surname/age"))
#     cost3.append(a)
# Costumer_info.append(cost1)
# Costumer_info.append(cost2)
# Costumer_info.append(cost3)
# costumer_index = int(input("enter index number 0/1/2"))
# if 0 <= costumer_index < len(Costumer_info):
#     Costumer_info = Costumer_info[costumer_index]
#     print("saxeli:", Costumer_info[0])
#     print("gvari:", Costumer_info[1])
#     print("asaki:", Costumer_info[2])

# 2   Online platform 
# userslist = [["Giorgi","34rfas343ed"]]
# users = []
# name = input("Enter login name:")
# password = input("enter your password:(should be at least 8 symbols long)")
# while len(name) >0 and len(password) >= 8:
#     users.append(name)
#     users.append(password)
#     break

# userslist.append(users)

# checkname = input("for login: enter your login name")
# checkpass = input("and enter your password:")



# for user_check in userslist:
#     if checkname == user_check[0] and checkpass == user_check[1]:
#         print("Login successful!")
#         break


   
# else:
#     print("Login failed. Invalid login name or password.")
          



# 3 movie stars
moviestars = [["Christian","Bale","1974 30 january","Christian Bale is an English actor who has received various awards and nominations for his film and television performances. His major nominations include four Academy Awards (one win), four British Academy Film Awards, twelve Critics' Choice Movie Awards (six wins), four Golden Globe Awards (two wins), and seven Screen Actors Guild Awards (two wins). Christian Bale was also nominated to the Nene Lopez Excellence Awards five times (three wins)."],
              ["Scarlett","Johansson", "1984 22 november","Scarlett Ingrid Johansson (/dʒoʊˈhænsən/;[1] born November 22, 1984) is an American actress. The world's highest-paid actress in 2018 and 2019, she has featured multiple times on the Forbes Celebrity 100 list. Time named her one of the 100 most influential people in the world in 2021. Johansson's films have grossed over $14.3 billion worldwide, making her the highest-grossing box office star of all time."]]
search = input("enter the actor's Name or Surname").lower()

for actor_search in moviestars:
    # Check if the inner list is not empty before accessing its elements
    if search == actor_search[0].lower() or search == actor_search[1].lower():
        print("Full name: ",actor_search[0],actor_search[1])
        print("Year of birth:",actor_search[2])
        print("Bio:",actor_search[3])
        



    



    





   

