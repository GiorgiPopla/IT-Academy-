# 1 რიცხვების წინადადებების და ასოების დათვლა
# asoebi = 0
# ricxvebi = 0
# simbolo = 0

# text = input("type the text!")
# for i in text:
#     if i.isalpha():
#         asoebi+=1
#     elif i.isdigit():
#         ricxvebi+=1
#     else:
#         simbolo+=1
# print("Textshi aris aso =",asoebi,"ricxvi =",ricxvebi,"simbolo =",simbolo )

# 2 წინადადებების შერწყმა
# import re
# text1=input("type first text:")
# text2 = input("type second text: ")
# divided1 = re.split("\s",text1)
# divided2 = re.split("\s",text2)
# print(divided1[0],divided2[-1],divided1[1],divided2[-2])


# 3 balanced strings

import re
text1 = input("type first text:")
text2 = input("type second text:")

divided1 = re.split("\s", text1)
divided2 = re.split("\s", text2)

print(divided1, divided2)
count = 0
for i in divided1:
    for j in divided2:
        if i == j:
            count += 1
        
if count == len(divided1) and count == len(divided2):
    print("balanced")
else:
    print("unbalanced")
