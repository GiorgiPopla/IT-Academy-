

# 1 rock scissors paper count to 3


print("welcome to the game of rock, scissors  and paper,one who scores 3 points wins the game!")
from random import choice
choice_list = ["rock", "scissors", "paper"]
human_score = 0
computer_score = 0

while human_score <3 and computer_score <3:
    computer_choice = choice(choice_list)

    human_choice = input("enter your choice: rock / scissors / paper").lower()
    if human_choice in choice_list:
        if human_choice == computer_choice:
            print("draw!")
        elif (
        (human_choice == "rock" and computer_choice == "scissors")
        or (human_choice == "scissors" and computer_choice == "paper")
        or (human_choice == "paper" and computer_choice == "rock")
        ):
            human_score += 1
            print("human wins!","human score:", human_score,"computer score:", computer_score)

        else:
            computer_score += 1
            print("computer wins!", "computer score:", computer_score,"human score:", human_score)
    else:
        print("please enter: rock, scissors or paper!")
if human_score == 3:
    print("Human wins the game!")
else:
    print("Computer wins the game!")


# 2 gamravlebis tabula


# ricxvi = int(input("enter the number"))
# for i in range(1, ricxvi + 1):
#     for j in range(1, ricxvi+1):
#         print(i * j, end=" ")
#     print()

# 3 Bank account


# balance = 3000
# while True:
#     try:
#         xarji = int(input("enter your expenses: (enter 0 to show balance )"))
#     except ValueError:
#         print("sheiyvanet Tanxa ricxvobriv machveneblit")
#         continue
#     if xarji == 0:
#         print("Mimdinare balansi: ", balance, "L")
#         break

#     elif xarji < balance:
#         balance = balance - xarji
#     else:
#         print("Not sufficient funds,expenses exceed Balance")
#         continue
#     print()

# 4 tutiyurshi
# while True:
#     name = input("type text").lower()
#     if name == "quit":
#         print("bye")
#         break
        
#     else:
#         print("„User Said Whaaat!?” ")
#         print(f"“User Said {name}” ")



