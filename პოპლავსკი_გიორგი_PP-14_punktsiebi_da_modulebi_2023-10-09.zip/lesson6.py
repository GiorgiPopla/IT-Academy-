
# shemoyvanili nfos gasamageba

# text = input("enter your text")
# def multiply():
#     print("output:",text*3)

# multiply()

# momxmareblis wona mtvareze

# text = int(input("enter your weight in KG"))
# def moon_weight():
#     print("your weight on moon would be: ",text/6)
# moon_weight()

# calculator
while True:
    calc = input("Enter your numbers and symbol to calculate (example: 5 + 4): ")
    calclist = calc.split()

    if len(calclist) == 3 and calclist[0].isdigit() and calclist[1] in "+*/-" and calclist[2].isdigit():
        if calclist[1] == "*":
            print(int(calclist[0]) * int(calclist[2]))
        elif calclist[1] == "/" and calclist[2] != "0":
            print(int(calclist[0]) / int(calclist[2]))
        elif calclist[1] == "-":
            print(int(calclist[0]) - int(calclist[2]))
        elif calclist[1] == "+":
            print(int(calclist[0]) + int(calclist[2]))
        elif int(calclist[0]) == 0 and calclist[1] == "/":
            print("Impossible to divide by zero")
        break
    else:
        print("Wrong input. Follow the instruction!")
