#task one
# lis = list(range(1, 12))
# mult5 = map(lambda x: x * 5, lis)
# print(list(mult5))

#task 2 
# namelist = ['Gio','Vaxo','Ana','salome','Tengo','Natia','ia']
# newnamelist = filter(lambda x : x[0].isupper(),namelist)
# print(len(list(newnamelist)))

# Task 3 

# from functools import reduce
# numlist = [-4,14,22,-10,15,-22]
# numlist2 = [1,2,3,-1,-2,-3]
# def sum_of_numbers(numlist):
#     positivenums = reduce(lambda a,b: a+b, list(filter(lambda x: x > 0,numlist)))
#     negativenums = reduce(lambda a,b: a+b, list(filter(lambda x: x < 0,numlist)))
#     print("Sum of positive numbers:", positivenums)
#     print("Sum of negative numbers:", negativenums)

# sum_of_numbers(numlist)
# sum_of_numbers(numlist2)

# task 4 
def make_deposit():
    while True:
        try:
            deposit = int(input("Type the amount to deposit: "))
            print("Deposit successful")
            return deposit
        except ValueError:
            print("Typed incorrectly. Please enter a valid integer.")

def create_user_account():
    username = input("Please type your username: ")
    password = input("Please type your password: ")
    deposit_amount = make_deposit()

    user_account = [username, password, deposit_amount]
    return user_account

user_accounts = []
user_accounts.append(create_user_account())

print(user_accounts)

      
def checkBalance(userlist):
    username_input = input("Enter your username: ")
    password_input = input("Enter your password: ")

    for user_account in userlist:
        if username_input == user_account[0] and password_input == user_account[1]:
            print("Successful login!")
            print("Balance:", user_account[2])
            break
    else:
        print("Wrong username or password")
        checkBalance(userlist)

checkBalance(user_accounts)


# while True:
#     print("please enter username and password")
#     validusername = input("Enter your username")
#     validuspassword = input("Enter your password")
#     try:
        




# lis = [1,2,3,4,5,6]
# def add5(num):
#     return num +5
# new_lis = list(map(add5,lis))
# print(new_lis)

# def even(n):
#     if n % 2 ==0:
#         return n
#     else:
#         return 'IS ODD'
# new_lis2 = list(map(even,lis))
# print(new_lis2)
# from functools import reduce
# lis = [1,22,34,3,14]
# Min_value = reduce(lambda a,b: a if a <b else b,lis)
# print(Min_value)

